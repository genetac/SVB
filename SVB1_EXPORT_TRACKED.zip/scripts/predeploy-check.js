#!/usr/bin/env node

/**
 * SURVIBE PREDEPLOY CHECK v1.0
 *
 * This script runs all major system checks required before deployment:
 * - Hardhat compile
 * - Hardhat tests
 * - TypeScript checks for onboarding-mobile & survibe-dev
 * - Dependency tree check
 * - Required module presence check
 * - Genesis QR file check
 * - Railgun wallet module check
 * - Noise handshake module check
 *
 * Output is a clean FLAG LIST for Codex/Continue to fix.
 */

const { execSync } = require("child_process");
const fs = require("fs");
const path = require("path");

// -----------------------------
// Utility Runner
// -----------------------------
function run(cmd, label, cwd = undefined) {
    console.log(`\n🔎 CHECK: ${label}`);

    try {
        const output = execSync(cmd, { encoding: "utf8", cwd });
        console.log(`✔ OK: ${label}`);
        return { ok: true, output };
    } catch (err) {
        console.log(`❌ FLAGGED: ${label}`);
        return { ok: false, output: err.stdout || err.message };
    }
}

let flags = [];
const ROOT = path.resolve(__dirname, "..");

// --------------------------------------------
// 1. Hardhat compilation (inside hardhat-env)
// --------------------------------------------
const compile = run("npx hardhat compile", "Hardhat Compilation", path.join(ROOT, "hardhat-env"));
if (!compile.ok) flags.push({ type: "compile", details: compile.output });

// --------------------------------------------
// 2. Hardhat tests
// --------------------------------------------
const tests = run("npx hardhat test", "Hardhat Tests", path.join(ROOT, "hardhat-env"));
if (!tests.ok) flags.push({ type: "tests", details: tests.output });

// --------------------------------------------
// 3. TypeScript checks
// --------------------------------------------

// onboarding-mobile
const tsMobile = run("npm run tsc", "TypeScript Check (onboarding-mobile)", path.join(ROOT, "onboarding-mobile"));
if (!tsMobile.ok) flags.push({ type: "typescript-mobile", details: tsMobile.output });

// survibe-dev
const tsWeb = run("npm run tsc", "TypeScript Check (survibe-dev)", path.join(ROOT, "survibe-dev"));
if (!tsWeb.ok) flags.push({ type: "typescript-web", details: tsWeb.output });

// --------------------------------------------
// 4. Dependency tree check
// --------------------------------------------
const deps = run("npm ls --depth=0", "Root Dependencies", ROOT);
if (!deps.ok) flags.push({ type: "dependencies", details: deps.output });

// --------------------------------------------
// 5. Mandatory module presence
// --------------------------------------------

function req(modulePath, description) {
    const full = path.join(ROOT, modulePath);
    if (!fs.existsSync(full)) {
        flags.push({
            type: "missing-module",
            details: `${description} missing: ${modulePath}`
        });
    }
}

req("services/noise/noiseXX.ts", "Noise Handshake");
req("services/security/finalSecurityCode.ts", "FinalSecurityCode Generator");
req("services/identity/semaphoreClient.ts", "Semaphore Identity Client");
req("services/wallet/shieldedWallet.ts", "Railgun Shielded Wallet");
req("services/qr/generateGenesisQR.ts", "Genesis QR Generator");
req("services/qr/validateGenesisQR.ts", "Genesis QR Validator");

// --------------------------------------------
// 6. ABI existence (after compile)
// --------------------------------------------
const artifactsDir = path.join(ROOT, "hardhat-env", "artifacts");
if (!fs.existsSync(artifactsDir) || fs.readdirSync(artifactsDir).length === 0) {
    flags.push({
        type: "abi",
        details: "ABI directory is empty. Run: cd hardhat-env && npx hardhat compile"
    });
}

// --------------------------------------------
// FINAL FLAG REPORT
// --------------------------------------------
console.log("\n====================================");
console.log("📘 SURVIBE PREDEPLOY FLAG REPORT");
console.log("====================================\n");

if (flags.length === 0) {
    console.log("🎉 All systems GREEN. Survibe is READY for deploy or audit.");
    process.exit(0);
}

for (let f of flags) {
    console.log(`⚠ FLAG TYPE: ${f.type}`);
    console.log(`👉 DETAILS:\n${f.details}\n`);
}

console.log("🟦 INSTRUCTIONS FOR FIXING:");
console.log("Use Codex or Continue with the Survibe rules:");
console.log("“Fix ONLY the flagged errors printed above. Make NO unrelated changes.”\n");

process.exit(1);
