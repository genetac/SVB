#!/bin/bash
set -e

echo "=== SURVIBE ONBOARDING CLEANUP / SETUP ==="
BASE_DIR="$HOME/svb/SVB1"
cd "$BASE_DIR"

echo "Base dir: $BASE_DIR"

BACKUP_DIR="$BASE_DIR/_backup_onboarding_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"

echo "Backup folder: $BACKUP_DIR"
echo

########################################
# 1. BACKUP EXISTING ONBOARDING FOLDERS
########################################

backup_if_exists () {
  local path="$1"
  local name="$2"

  if [ -d "$path" ]; then
    echo "↪ Backing up $name from $path ..."
    mv "$path" "$BACKUP_DIR/$name"
  else
    echo "ℹ $name not found at $path (ok)"
  fi
}

echo "== Step 1: Backing up existing onboarding projects =="

backup_if_exists "$BASE_DIR/onboarding-mobile-app" "onboarding-mobile-app_root"
backup_if_exists "$BASE_DIR/onboarding-mobile" "onboarding-mobile_root"
backup_if_exists "$BASE_DIR/onboarding-web" "onboarding-web_root"
backup_if_exists "$BASE_DIR/onboarding-desktop" "onboarding-desktop_root"

backup_if_exists "$BASE_DIR/survibe-dev/onboarding-mobile" "onboarding-mobile_in_survibe-dev"
backup_if_exists "$BASE_DIR/survibe-dev/onboarding-web" "onboarding-web_in_survibe-dev"
backup_if_exists "$BASE_DIR/survibe-dev/onboarding-desktop" "onboarding-desktop_in_survibe-dev"

echo
echo "== Step 2: Create clean target folders =="

mkdir -p "$BASE_DIR/onboarding-mobile"
mkdir -p "$BASE_DIR/onboarding-web"
mkdir -p "$BASE_DIR/onboarding-desktop"

echo "Created:"
echo "  $BASE_DIR/onboarding-mobile"
echo "  $BASE_DIR/onboarding-web"
echo "  $BASE_DIR/onboarding-desktop"
echo

########################################
# 3. OPTIONAL: COPY SOURCES FROM BACKUP
########################################

# If you want to reuse previous code, we can later selectively copy files
# from $BACKUP_DIR into these clean folders.
# For now we just set up clean structure.

echo "== Step 3: Cleaning node_modules & lockfiles in new onboarding apps =="

clean_project () {
  local path="$1"
  if [ -d "$path" ]; then
    echo "→ Cleaning $path"
    rm -rf "$path/node_modules"
    rm -f "$path/package-lock.json" "$path/pnpm-lock.yaml" "$path/yarn.lock"
  fi
}

clean_project "$BASE_DIR/onboarding-mobile"
clean_project "$BASE_DIR/onboarding-web"
clean_project "$BASE_DIR/onboarding-desktop"

echo
echo "== Step 4: Summary =="
echo "• Old onboarding projects are backed up in: $BACKUP_DIR"
echo "• Clean folders ready:"
echo "    - $BASE_DIR/onboarding-mobile   (Expo mobile target)"
echo "    - $BASE_DIR/onboarding-web      (Vite web target)"
echo "    - $BASE_DIR/onboarding-desktop  (future desktop app)"
echo
echo "Next steps will be:"
echo "  1) Initialize Expo app in onboarding-mobile"
echo "  2) Initialize Vite app in onboarding-web"
echo "  3) Paste Survibe QR / Noise / identity code into those clean apps"
echo
echo "=== DONE: base structure cleaned. You can now proceed to Phase 2. ==="
