const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3000;
const qrTokens = new Set();

app.get("/", (req, res) => {
  res.json({ ok: true, message: "Survibe QR backend running" });
});

app.post("/generate", (req, res) => {
  const token = "t_" + Math.random().toString(36).substring(2, 10);
  qrTokens.add(token);
  console.log("🟢 GENERATED token:", token);
  res.json({ success: true, token });
});

app.post("/handshake/qr-complete", (req, res) => {
  const { token } = req.body;
  console.log("📥 /handshake/qr-complete token:", token);

  if (!token) {
    return res.status(400).json({ success: false, message: "Missing token" });
  }

  qrTokens.add(token);
  return res.json({ success: true });
});

app.post("/handshake/finalize", (req, res) => {
  const { token } = req.body;
  console.log("🤝 /handshake/finalize token:", token);

  if (!token) {
    return res.status(400).json({ success: false, message: "Missing token" });
  }

  if (!qrTokens.has(token)) {
    console.log("⚠️ Token not in set, allowing anyway for dev.");
  }

  return res.json({ success: true, message: "Handshake OK" });
});

app.post("/authenticator/verify", (req, res) => {
  const { token, code } = req.body;
  console.log("🔐 /authenticator/verify token:", token, "code:", code);

  if (!token || !code) {
    return res
      .status(400)
      .json({ success: false, message: "Missing token or code" });
  }

  if (code.length === 6) {
    return res.json({
      success: true,
      session: `session_${token}_${Date.now()}`,
    });
  }

  return res.json({ success: false, message: "Invalid code" });
});

app.listen(PORT, () => {
  console.log(`🚀 Survibe QR backend listening on http://0.0.0.0:${PORT}`);
});
