export function validateGenesisQR() {
  return true;
}
