export function generateGenesisQR() {
  return "QR_A_PLACEHOLDER";
}
