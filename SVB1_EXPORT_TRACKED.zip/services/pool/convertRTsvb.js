import { pullOneSVB, saveRTSVB } from "./svb.js";

const STAKED_RATE = 0.89;
const LIQUID_RATE = 0.91;

function toFourDecimals(value) {
  return Number(value.toFixed(4));
}

export async function convertSVBtoRTSVB(address) {
  const pulled = await pullOneSVB(address);

  const rtsvb = {
    staked: toFourDecimals(pulled * STAKED_RATE),
    liquid: toFourDecimals(pulled * LIQUID_RATE),
    total: pulled
  };

  await saveRTSVB(address, rtsvb);
  return rtsvb;
}
