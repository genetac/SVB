const poolState = {
  available: 1000,
  allocations: new Map(),
  rewards: new Map()
};

export function getPoolSnapshot() {
  return {
    available: poolState.available,
    allocations: poolState.allocations.size
  };
}

export async function pullOneSVB(address) {
  if (!address) {
    throw new Error("Wallet address required");
  }

  if (poolState.available <= 0) {
    throw new Error("SVB pool is empty");
  }

  poolState.available -= 1;
  const allocated = poolState.allocations.get(address) || 0;
  poolState.allocations.set(address, allocated + 1);
  return 1;
}

export async function saveRTSVB(address, payload) {
  poolState.rewards.set(address, payload);
  return payload;
}

export function getRTSVB(address) {
  return poolState.rewards.get(address) || null;
}
