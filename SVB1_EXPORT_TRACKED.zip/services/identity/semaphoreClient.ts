export function createSemaphoreIdentity() {
  return {
    commitment: "PLACEHOLDER",
    nullifier: "PLACEHOLDER",
    trapdoor: "PLACEHOLDER"
  };
}
