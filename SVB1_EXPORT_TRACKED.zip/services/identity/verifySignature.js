import { recoverMessageAddress } from "viem";

export function buildLoginMessage(sessionId) {
  if (!sessionId) {
    throw new Error("Missing sessionId");
  }

  return `Survibe login session: ${sessionId}`;
}

export async function verifySignature(sessionId, signature) {
  if (!signature) {
    throw new Error("Missing signature");
  }

  try {
    const address = await recoverMessageAddress({
      message: buildLoginMessage(sessionId),
      signature
    });
    return address;
  } catch (err) {
    const reason = err instanceof Error ? err.message : "unknown error";
    throw new Error(`Unable to verify signature: ${reason}`);
  }
}
