import { randomUUID } from "node:crypto";

const sessions = new Map();

function buildSession(id, overrides = {}) {
  const now = Date.now();
  return {
    id,
    status: "pending",
    createdAt: now,
    updatedAt: now,
    address: null,
    signature: null,
    rewards: null,
    ...overrides
  };
}

export function createSession(metadata = {}) {
  const id = randomUUID();
  const session = buildSession(id, metadata);
  sessions.set(id, session);
  return session;
}

export function getSession(sessionId) {
  return sessions.get(sessionId) || null;
}

export function completeSession(sessionId, { address, signature, rewards }) {
  const existing = sessions.get(sessionId);
  if (!existing) {
    throw new Error(`Session ${sessionId} not found`);
  }

  const updated = {
    ...existing,
    status: "verified",
    address,
    signature,
    rewards,
    updatedAt: Date.now()
  };

  sessions.set(sessionId, updated);
  return updated;
}

export function clearSessions() {
  sessions.clear();
}
