#!/bin/bash
echo "🌐 Starting Survibe Local Testnet..."

tmux new-session -d -s survibe \
  "cd hardhat-env && pnpm hardhat node"

tmux split-window -h "cd survibe-dev && pnpm dev"
tmux split-window -v "cd onboarding-mobile && pnpm start"

tmux attach -t survibe
