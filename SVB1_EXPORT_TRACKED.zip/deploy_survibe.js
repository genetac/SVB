const { spawnSync } = require("child_process");
const path = require("path");

const cwd = path.join(__dirname, "hardhat-env");
const result = spawnSync("npx", ["hardhat", "run", "scripts/deploy.ts"], {
  cwd,
  stdio: "inherit"
});

if (result.status !== 0) {
  process.exit(result.status ?? 1);
}
