import { expect } from "chai";
import { ethers } from "hardhat";
import { time, loadFixture } from "@nomicfoundation/hardhat-network-helpers";

import type {
  FounderTimelock,
  GenesisFinalizer,
  RWAVault,
  SurvibeEngine,
  VestingWhitelist,
  VSVB
} from "../typechain-types";

const BPS = 10_000n;
const DUST_TOLERANCE = 5n;

const expectDustClose = (actual: bigint, expected: bigint) => {
  const diff = actual > expected ? actual - expected : expected - actual;
  expect(diff).to.lte(DUST_TOLERANCE);
};

async function deployCore() {
  const [
    deployer,
    buyer,
    founder,
    lp,
    infra,
    buffer,
    verifierA,
    verifierB,
    whitelistUser1,
    whitelistUser2,
    whitelistUser3
  ] = await ethers.getSigners();

  const vsvb = (await ethers.deployContract("vSVB", [deployer.address])) as unknown as VSVB;
  const rwaVault = (await ethers.deployContract("RWAVault", [
    await vsvb.getAddress(),
    deployer.address
  ])) as unknown as RWAVault;
  const whitelist = (await ethers.deployContract("VestingWhitelist", [
    await vsvb.getAddress(),
    deployer.address
  ])) as unknown as VestingWhitelist;

  const engine = (await ethers.deployContract("SurvibeEngine", [
    await vsvb.getAddress(),
    founder.address,
    lp.address,
    infra.address,
    buffer.address,
    await rwaVault.getAddress(),
    await whitelist.getAddress()
  ])) as unknown as SurvibeEngine;

  const engineAddress = await engine.getAddress();
  await vsvb.setTransferAgent(engineAddress, true);
  await vsvb.setTransferBypass(engineAddress, true);
  await vsvb.setTransferBypass(await rwaVault.getAddress(), true);
  const founderTimelock = await engine.founderTimelock();
  await vsvb.setTransferBypass(founderTimelock, true);
  await vsvb.transfer(engineAddress, await vsvb.balanceOf(deployer.address));
  await rwaVault.setEngine(await engine.getAddress());
  await whitelist.setEngine(await engine.getAddress());

  const finalizer = (await ethers.deployContract("GenesisFinalizer", [
    deployer.address,
    await vsvb.getAddress(),
    await whitelist.getAddress(),
    verifierA.address,
    verifierB.address
  ])) as unknown as GenesisFinalizer;

  const wlAccounts = [whitelistUser1.address, whitelistUser2.address, whitelistUser3.address];
  const eurValues = [5_000_000n, 1_000_000n, 500_000n];
  const rateBps = [100n, 50n, 30n];
  await whitelist.setParticipants(wlAccounts, eurValues, rateBps);

  await vsvb.transferOwnership(await finalizer.getAddress());
  await whitelist.transferOwnership(await finalizer.getAddress());

  return {
    deployer,
    buyer,
    founder,
    lp,
    infra,
    buffer,
    verifierA,
    verifierB,
    whitelistUser1,
    whitelistUser2,
    whitelistUser3,
    vsvb,
    rwaVault,
    whitelist,
    engine,
    finalizer,
    founderTimelock
  };
}

async function deployWhitelistFixture() {
  const [deployer] = await ethers.getSigners();
  const vsvb = await ethers.deployContract("vSVB", [deployer.address]);
  const whitelist = (await ethers.deployContract("VestingWhitelist", [
    await vsvb.getAddress(),
    deployer.address
  ])) as unknown as VestingWhitelist;
  return { whitelist };
}

describe("Survibe v1.1", () => {
  describe("Engine routing", () => {
    it("SPEC LOCK: mint split constants sum to 100% and match v1.1", async () => {
      const { engine } = await loadFixture(deployCore);
      expect(await engine.BUYER_MINT_BPS()).to.equal(6700n);
      expect(await engine.RWA_RESERVE_BPS()).to.equal(1500n);
      expect(await engine.INFRA_BPS()).to.equal(700n);
      expect(await engine.VESTING_LOCK_BPS()).to.equal(400n);
      expect(await engine.WHITELIST_POOL_BPS()).to.equal(400n);
      expect(await engine.GRA_BPS()).to.equal(300n);

      const total =
        (await engine.BUYER_MINT_BPS()) +
        (await engine.RWA_RESERVE_BPS()) +
        (await engine.INFRA_BPS()) +
        (await engine.VESTING_LOCK_BPS()) +
        (await engine.WHITELIST_POOL_BPS()) +
        (await engine.GRA_BPS());
      expect(total).to.equal(10_000n);
    });

    it("routes taxes and mint lane splits exactly", async () => {
      const { buyer, founder, lp, infra, buffer, vsvb, rwaVault, whitelist, engine, founderTimelock } =
        await loadFixture(deployCore);

      const amountIn = ethers.parseEther("1000");
      await engine.connect(buyer).enter(amountIn);

      const founderTax = (amountIn * 50n) / BPS;
      const lpTax = (amountIn * 100n) / BPS;
      const afterTax = amountIn - founderTax - lpTax;
      const buyerImmediate = (afterTax * 3400n) / BPS;
      const mintPortion = afterTax - buyerImmediate;

      let buyerMint = (mintPortion * 6700n) / BPS;
      const rwaMint = (mintPortion * 1500n) / BPS;
      const infraMint = (mintPortion * 700n) / BPS;
      const lockedMint = (mintPortion * 400n) / BPS;
      const whitelistMint = (mintPortion * 400n) / BPS;
      const bufferMint = (mintPortion * 300n) / BPS;

      const distributed = buyerMint + rwaMint + infraMint + lockedMint + whitelistMint + bufferMint;
      if (distributed < mintPortion) {
        buyerMint += mintPortion - distributed;
      }

      expectDustClose(await vsvb.balanceOf(founder.address), founderTax);
      expectDustClose(await vsvb.balanceOf(lp.address), lpTax);
      expectDustClose(await vsvb.balanceOf(buyer.address), buyerImmediate + buyerMint);
      expectDustClose(await vsvb.balanceOf(await rwaVault.getAddress()), rwaMint);
      expectDustClose(await vsvb.balanceOf(infra.address), infraMint);
      expectDustClose(await vsvb.balanceOf(founderTimelock), lockedMint);
      expectDustClose(await vsvb.balanceOf(buffer.address), bufferMint);
      expectDustClose(await whitelist.whitelistPool(), whitelistMint);

      const maxSupply = await vsvb.MAX_SUPPLY();
      expect(await vsvb.balanceOf(await engine.getAddress())).to.equal(maxSupply - amountIn);
    });

    it("locks vesting (4% of mint lane) into FounderTimelock and unlocks after 6 months", async () => {
      const { buyer, founder, engine, vsvb } = await loadFixture(deployCore);

      const timelockAddr = await engine.founderTimelock();
      expect(timelockAddr).to.properAddress;

      const amountIn = ethers.parseEther("500");
      await engine.connect(buyer).enter(amountIn);

      const before = await vsvb.balanceOf(timelockAddr);
      expect(before).to.be.gt(0n);

      const timelock = (await ethers.getContractAt("FounderTimelock", timelockAddr)) as FounderTimelock;

      await expect(timelock.connect(founder).claim()).to.be.revertedWith("still locked");

      await time.increase(180 * 24 * 60 * 60);

      await timelock.connect(founder).claim();

      const after = await vsvb.balanceOf(timelockAddr);
      expect(after).to.equal(0n);
    });
  });

  describe("Whitelist distribution + genesis finalization", () => {
    it("requires 2-of-2 approvals and distributes whitelist at 46.34%", async () => {
      const {
        buyer,
        lp,
        verifierA,
        verifierB,
        vsvb,
        whitelist,
        finalizer,
        engine
      } = await loadFixture(deployCore);

      const amountIn = ethers.parseEther("1000");
      await engine.connect(buyer).enter(amountIn);

      await expect(vsvb.connect(buyer).transfer(lp.address, 1n)).to.be.revertedWith("trading disabled");

      await expect(finalizer.connect(verifierA).approveGenesis()).to.emit(finalizer, "GenesisApproved");
      expect(await vsvb.tradingEnabled()).to.equal(false);

      await expect(finalizer.connect(verifierB).approveGenesis())
        .to.emit(finalizer, "GenesisFinalized")
        .and.to.emit(finalizer, "vSVBLaunched");

      expect(await vsvb.tradingEnabled()).to.equal(true);
      await vsvb.connect(buyer).transfer(lp.address, 1n);

      const whitelistMint = await whitelist.whitelistPool();
      const expectedDistributed = (whitelistMint * 4634n) / BPS;
      const distributedAmount = await whitelist.distributedAmount();
      const distributedDiff =
        distributedAmount > expectedDistributed
          ? distributedAmount - expectedDistributed
          : expectedDistributed - distributedAmount;
      expect(distributedDiff).to.lte(5n);

      const participants = [
        await whitelist.getParticipant(0),
        await whitelist.getParticipant(1),
        await whitelist.getParticipant(2)
      ];
      const totalWeight = participants.reduce(
        (acc, p) => acc + p.eurValue * p.bonusRateBps,
        0n
      );

      for (const participant of participants) {
        const weight = participant.eurValue * participant.bonusRateBps;
        const expectedShare = (expectedDistributed * weight) / totalWeight;
        const balance = await vsvb.balanceOf(participant.account);
        const diff = balance > expectedShare ? balance - expectedShare : expectedShare - balance;
        expect(diff).to.lte(5n);
      }
    });

    it("caps whitelist participants at 333", async () => {
  const { whitelist } = await loadFixture(deployWhitelistFixture);
  await expect(
    whitelist.setParticipants(
      Array(334).fill(ethers.ZeroAddress),
      Array(334).fill(1),
      Array(334).fill(1)
    )
  ).to.be.revertedWith("exceeds cap");
  });
  });

  describe("RWA vault lock schedule", () => {
    it("locks for 12 months then unlocks 50% until integration", async () => {
      const { buyer, rwaVault, engine, buffer } = await loadFixture(deployCore);
      const amountIn = ethers.parseEther("1000");
      await engine.connect(buyer).enter(amountIn);
      const [, unlockedBefore] = await rwaVault.unlockSchedule();
      expect(unlockedBefore).to.equal(0n);

      await time.increase(365 * 24 * 60 * 60 + 1);
      const [totalReceived, unlockedAfter] = await rwaVault.unlockSchedule();
      expect(unlockedAfter).to.equal(totalReceived / 2n);

      await expect(rwaVault.tryWithdrawUnlocked(buffer.address, unlockedAfter + 1n)).to.be.revertedWith(
        "amount exceeds unlocked"
      );
      await rwaVault.tryWithdrawUnlocked(buffer.address, unlockedAfter);
      const [, unlockedPostWithdraw] = await rwaVault.unlockSchedule();
      expect(unlockedPostWithdraw).to.equal(0n);

      await rwaVault.setAssetIntegrated(true);
      const [, unlockedPostIntegration] = await rwaVault.unlockSchedule();
      expect(unlockedPostIntegration).to.equal(totalReceived - unlockedAfter);
      await rwaVault.tryWithdrawUnlocked(buffer.address, unlockedPostIntegration);
      const [, finalUnlocked] = await rwaVault.unlockSchedule();
      expect(finalUnlocked).to.equal(0n);
    });
  });
});
