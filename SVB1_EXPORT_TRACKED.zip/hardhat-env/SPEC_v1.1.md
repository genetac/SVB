# Survibe v1.1 Economics Snapshot

Frozen reference for Survibe v1.1 so stakeholders cannot misremember the configuration. All values are final unless the spec is versioned forward.

## Mint Lane (66% engine share)

Percentages below are of the Mint Lane (100% of the 66%):

- Buyer (liquid mint): 67%
- RWA reserve (vaulted): 15%
- Infrastructure & dev: 7%
- Vesting & whitelist pool: 8% total
  - FounderTimelock: 4% (locked 180 days)
  - Whitelist / community pool: 4%
- GRA buffer: 3%

## Taxes

- Buy tax: 1.5% (0.5% founder allocation, 1.0% LP vault)
- Sell tax: 3.0% (1.0% founder allocation, 2.0% LP vault)

## Key invariants

- Engine keeps the 66% Mint Lane / 34% Immediate Lane invariant.
- `vSVB` supply cannot inflate beyond the predefined cap.
- Transfer bypass is granted only to system contracts (engine, vaults, whitelist, timelock) so secondary trading stays gated until launch.
