import { ethers } from "hardhat";

const toAddr = (value: string | undefined, fallback: string) =>
  value && value !== "" ? value : fallback;

async function main() {
  const [deployer] = await ethers.getSigners();
  const balance = await deployer.provider!.getBalance(deployer);

  console.log("🚀 Deploying Survibe v1.1 core with:", deployer.address);
  console.log("   Balance:", ethers.formatEther(balance), "ETH");

  const founder = toAddr(process.env.SURVIBE_FOUNDER, deployer.address);
  const lpVault = toAddr(process.env.SURVIBE_LP_VAULT, deployer.address);
  const infrastructure = toAddr(process.env.SURVIBE_INFRA, deployer.address);
  const graBuffer = toAddr(process.env.SURVIBE_GRA_BUFFER, deployer.address);
  const verifierA = toAddr(process.env.SURVIBE_VERIFIER_A, deployer.address);
  const verifierB = toAddr(process.env.SURVIBE_VERIFIER_B, deployer.address);

  const vSVB = await ethers.deployContract("vSVB", [deployer.address]);
  await vSVB.waitForDeployment();
  console.log("✅ vSVB deployed:", await vSVB.getAddress());

  const rwaVault = await ethers.deployContract("RWAVault", [await vSVB.getAddress(), deployer.address]);
  await rwaVault.waitForDeployment();
  console.log("✅ RWAVault deployed:", await rwaVault.getAddress());

  const vestingWhitelist = await ethers.deployContract("VestingWhitelist", [
    await vSVB.getAddress(),
    deployer.address
  ]);
  await vestingWhitelist.waitForDeployment();
  console.log("✅ VestingWhitelist deployed:", await vestingWhitelist.getAddress());

  const engine = await ethers.deployContract("SurvibeEngine", [
    await vSVB.getAddress(),
    founder,
    lpVault,
    infrastructure,
    graBuffer,
    await rwaVault.getAddress(),
    await vestingWhitelist.getAddress()
  ]);
  await engine.waitForDeployment();
  console.log("✅ SurvibeEngine deployed:", await engine.getAddress());

  await (await rwaVault.setEngine(await engine.getAddress())).wait();
  await (await vestingWhitelist.setEngine(await engine.getAddress())).wait();
  await (await vSVB.setTransferAgent(await engine.getAddress(), true)).wait();
  const engineAddress = await engine.getAddress();
  await (await vSVB.setTransferBypass(engineAddress, true)).wait();
  await (await vSVB.setTransferBypass(await rwaVault.getAddress(), true)).wait();
  const founderTimelock = await engine.founderTimelock();
  await (await vSVB.setTransferBypass(founderTimelock, true)).wait();

  const genesis = await ethers.deployContract("GenesisFinalizer", [
    deployer.address,
    await vSVB.getAddress(),
    await vestingWhitelist.getAddress(),
    verifierA,
    verifierB
  ]);
  await genesis.waitForDeployment();
  console.log("✅ GenesisFinalizer deployed:", await genesis.getAddress());

  await (await vSVB.transfer(await engine.getAddress(), await vSVB.balanceOf(deployer.address))).wait();
  console.log("🔄 vSVB supply moved to engine");

  await (await vSVB.transferOwnership(await genesis.getAddress())).wait();
  await (await vestingWhitelist.transferOwnership(await genesis.getAddress())).wait();
  console.log("🔐 Ownership delegated to GenesisFinalizer");

  console.log("\nDeployment complete. Trading remains disabled until genesis approvals execute.");
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
